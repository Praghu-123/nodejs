# Angular-Weather-Widget
Angular Weather Widget Created Using the Open Weather Map api.
